# seleniumProjectTemplate
initial startup project for selenium tests
