﻿using OpenQA.Selenium.Chrome;
using $safeprojectname$.WebDriver.Builders.Base;

namespace $safeprojectname$.WebDriver.Builders
{
    public class ChromeDriverBuilder : WebDriverBuilder<ChromeDriver>
    {
        public override void Build(string binariesDirectory)
        {
            this.WebDriver = new ChromeDriver(binariesDirectory);
        }

        public override ChromeDriver GetResult()
        {
            return this.WebDriver;
        }
    }
}