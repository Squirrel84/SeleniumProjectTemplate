﻿namespace $safeprojectname$.WebDriver.Builders.Base
{
    public interface IWebDriverBuilder
    {
        void Build(string binariesDirectory);
    }
}