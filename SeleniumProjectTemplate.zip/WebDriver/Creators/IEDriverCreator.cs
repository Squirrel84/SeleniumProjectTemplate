﻿using OpenQA.Selenium;
using $safeprojectname$.WebDriver.Builders;
using $safeprojectname$.WebDriver.Creators.Base;

namespace $safeprojectname$.WebDriver.Creators
{
    public class IEDriverCreator : WebDriverCreator
    {
        public override IWebDriver Create(WebDriverConstructor constructor)
        {
            var builder = new InternetExplorerDriverBuilder();
            constructor.Construct(builder);
            return builder.GetResult();
        }
    }
}