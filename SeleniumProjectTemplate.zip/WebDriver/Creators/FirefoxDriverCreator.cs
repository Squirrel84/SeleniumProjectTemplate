﻿using OpenQA.Selenium;
using $safeprojectname$.WebDriver.Builders;
using $safeprojectname$.WebDriver.Creators.Base;

namespace $safeprojectname$.WebDriver.Creators
{
    public class FirefoxDriverCreator : WebDriverCreator
    {
        public override IWebDriver Create(WebDriverConstructor constructor)
        {
            var builder = new FirefoxDriverBuilder();
            constructor.Construct(builder);
            return builder.GetResult();
        }
    }
}
