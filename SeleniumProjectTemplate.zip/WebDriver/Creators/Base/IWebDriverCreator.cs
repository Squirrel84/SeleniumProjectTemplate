﻿using OpenQA.Selenium;

namespace $safeprojectname$.WebDriver.Creators.Base
{
    public interface IWebDriverCreator
    {
        IWebDriver Create(WebDriverConstructor webDriverConstructor);
    }
}