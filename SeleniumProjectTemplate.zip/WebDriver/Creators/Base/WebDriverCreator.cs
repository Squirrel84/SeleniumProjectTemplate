﻿using OpenQA.Selenium;

namespace $safeprojectname$.WebDriver.Creators.Base
{
    public abstract class WebDriverCreator : IWebDriverCreator
    {
        public abstract IWebDriver Create(WebDriverConstructor constructor);
    }
}
